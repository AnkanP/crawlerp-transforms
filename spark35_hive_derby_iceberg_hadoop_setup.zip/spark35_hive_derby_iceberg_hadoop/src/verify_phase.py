import argparse
from src.spark_session import make_spark, load_config


def main(config_path: str = None):
    cfg = load_config(config_path)
    spark = make_spark(config_path)

    hive_table = cfg.get("hive_table", "hdb.hive_tbl")
    iceberg_table = cfg.get("iceberg_table", "ice.idb.ice_tbl")

    print("=== Verify Hive table data ===")
    spark.sql(f"SELECT * FROM {hive_table} ORDER BY id").show(truncate=False)

    print("=== Verify Iceberg table data (latest) ===")
    spark.sql(f"SELECT id, name, ts FROM {iceberg_table} ORDER BY id").show(truncate=False)

    spark.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None, help="Path to conf/config.json (optional)")
    args = parser.parse_args()
    main(args.config)
