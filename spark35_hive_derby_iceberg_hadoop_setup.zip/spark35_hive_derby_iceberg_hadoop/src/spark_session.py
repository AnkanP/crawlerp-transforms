import os
import json
from pyspark.sql import SparkSession


def _expand(path: str) -> str:
    return os.path.abspath(os.path.expanduser(path))


def load_config(config_path: str = None) -> dict:
    """Load JSON config. If config_path is None, loads conf/config.json relative to repo root."""
    if config_path is None:
        here = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(os.path.dirname(here), "conf", "config.json")
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    base_dir = _expand(cfg.get("base_dir", "~/local_catalogs"))
    paths = cfg.get("paths", {})
    cfg["_resolved_paths"] = {
        "base_dir": base_dir,
        "hive_metastore_db": os.path.join(base_dir, paths.get("hive_metastore_db", "hive_metastore_db")),
        "hive_warehouse": os.path.join(base_dir, paths.get("hive_warehouse", "hive_warehouse")),
        "iceberg_warehouse": os.path.join(base_dir, paths.get("iceberg_warehouse", "iceberg_warehouse")),
    }
    return cfg


def make_spark(config_path: str = None) -> SparkSession:
    """Create SparkSession for:
    - Hive metastore persisted via Derby (on-disk)
    - Iceberg persisted via Hadoop catalog (on-disk warehouse)
    """
    cfg = load_config(config_path)
    rp = cfg["_resolved_paths"]

    os.makedirs(rp["hive_metastore_db"], exist_ok=True)
    os.makedirs(rp["hive_warehouse"], exist_ok=True)
    os.makedirs(rp["iceberg_warehouse"], exist_ok=True)

    spark = (
        SparkSession.builder
        .appName("spark35-hive-derby-and-iceberg-hadoop")
        .master("local[*]")

        # Persist Hive/Spark SQL tables using Derby metastore
        .config("spark.sql.catalogImplementation", "hive")
        .config("spark.sql.warehouse.dir", rp["hive_warehouse"])
        .config(
            "javax.jdo.option.ConnectionURL",
            f"jdbc:derby:;databaseName={rp['hive_metastore_db']};create=true"
        )
        .config("javax.jdo.option.ConnectionDriverName", "org.apache.derby.jdbc.EmbeddedDriver")
        .config("datanucleus.schema.autoCreateAll", "true")
        .config("hive.metastore.schema.verification", "false")
        .enableHiveSupport()

        # Persist Iceberg tables using Hadoop catalog
        .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        .config("spark.sql.catalog.ice", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.ice.type", "hadoop")
        .config("spark.sql.catalog.ice.warehouse", rp["iceberg_warehouse"])

        .getOrCreate()
    )

    return spark
