import argparse
from pyspark.sql import functions as F
from src.spark_session import make_spark, load_config


def main(config_path: str = None):
    cfg = load_config(config_path)
    spark = make_spark(config_path)

    hive_db = cfg.get("hive_db", "hdb")
    hive_table = cfg.get("hive_table", "hdb.hive_tbl")
    iceberg_ns = cfg.get("iceberg_namespace", "ice.idb")
    iceberg_table = cfg.get("iceberg_table", "ice.idb.ice_tbl")

    # Hive (Derby metastore)
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {hive_db}")
    spark.sql(f"CREATE TABLE IF NOT EXISTS {hive_table} (id INT, name STRING) USING parquet")
    spark.sql(f"INSERT INTO {hive_table} VALUES (1,'a'),(2,'b')")

    # Iceberg (Hadoop catalog)
    spark.sql(f"CREATE NAMESPACE IF NOT EXISTS {iceberg_ns}")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS {iceberg_table} (
        id INT,
        name STRING,
        ts TIMESTAMP
    ) USING iceberg""")

    df = spark.createDataFrame([(10, "x"), (20, "y")], "id int, name string").withColumn("ts", F.current_timestamp())
    df.createOrReplaceTempView("tmp_ins")
    spark.sql(f"INSERT INTO {iceberg_table} SELECT id, name, ts FROM tmp_ins")

    print("=== Hive tables ===")
    spark.sql(f"SHOW TABLES IN {hive_db}").show(truncate=False)
    print("=== Iceberg tables ===")
    spark.sql(f"SHOW TABLES IN {iceberg_ns}").show(truncate=False)

    spark.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None, help="Path to conf/config.json (optional)")
    args = parser.parse_args()
    main(args.config)
