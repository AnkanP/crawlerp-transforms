# Local Spark 3.5: Persistent Hive (Derby) + Persistent Iceberg (Hadoop catalog)

This package gives you a **setup phase** that:
- persists **Hive/Spark SQL tables** using an on-disk **Derby-backed Hive metastore**
- persists **Iceberg tables** using an **Iceberg Hadoop catalog** (warehouse on disk)

Designed for a local environment where you run Spark from a Python venv with `pyspark` installed via pip.

## What you get
- `src/spark_session.py` : SparkSession configured for Derby (Hive) + Iceberg Hadoop catalog
- `src/setup_phase.py`   : Setup script to create + load sample Hive and Iceberg tables
- `src/verify_phase.py`  : Verifies persistence across restarts
- `conf/config.json`     : Paths + table names
- `bin/run_setup.sh`     : Convenience script
- `bin/run_verify.sh`    : Convenience script

## Configure paths
Edit `conf/config.json` and set `base_dir` to a stable location (not `/tmp` if you want persistence).
Default is `~/local_catalogs`.

## Run: setup phase
From your venv:

```bash
export ICEBERG_VER=1.5.2
bash bin/run_setup.sh
```

## Run: verify phase (new process)
```bash
export ICEBERG_VER=1.5.2
bash bin/run_verify.sh
```

If both scripts work, you have persistence across sessions for:
- Hive table: `hdb.hive_tbl`
- Iceberg table: `ice.idb.ice_tbl`

## Notes / gotchas
- Derby metastore allows only **one writer process** at a time for the same metastore path.
  If you run parallel tests/jobs, use distinct `hive_metastore_db` paths per worker.
- Iceberg persistence requires using the same `ice.warehouse` path each run.
