# Option 2: One artifact per job (Spark 3.5) — multi-package monorepo

Template for **independent job versioning**:
- `libs/myproj_common` -> shared framework (wheel/zip)
- `jobs/job1_pkg`      -> job1 package + entrypoint
- `jobs/job2_pkg`      -> job2 package + entrypoint

## Prereqs
```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install pyspark==3.5.*
pip install -U build
```

## Build artifacts
```bash
bin/build_all.sh
```

## Submit with wheels
```bash
export ICEBERG_VER=1.5.2

spark-submit \
  --packages "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:${ICEBERG_VER}" \
  --py-files dist/myproj_common-0.1.0-py3-none-any.whl,dist/job1_pkg-0.1.0-py3-none-any.whl \
  jobs/job1_pkg/app/run_job1.py --arg db=hdb --arg table=job1_out

spark-submit \
  --packages "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:${ICEBERG_VER}" \
  --py-files dist/myproj_common-0.1.0-py3-none-any.whl,dist/job2_pkg-0.1.0-py3-none-any.whl \
  jobs/job2_pkg/app/run_job2.py --arg namespace=ice.idb --arg table=job2_ice_out
```

## Submit with zips (dev-friendly)
```bash
bin/build_zips.sh

spark-submit \
  --packages "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:${ICEBERG_VER}" \
  --py-files dist/myproj_common.zip,dist/job1_pkg.zip \
  jobs/job1_pkg/app/run_job1.py

spark-submit \
  --packages "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:${ICEBERG_VER}" \
  --py-files dist/myproj_common.zip,dist/job2_pkg.zip \
  jobs/job2_pkg/app/run_job2.py
```

## Version controlling individual jobs
- Bump versions independently:
  - `jobs/job1_pkg/pyproject.toml`
  - `jobs/job2_pkg/pyproject.toml`
- Bump common only when shared code changes:
  - `libs/myproj_common/pyproject.toml`

Suggested git tags:
- `common/v0.1.0`
- `job1/v0.1.0`
- `job2/v0.1.0`

CI (path-based):
- changes under `jobs/job1_pkg/**` -> release job1
- changes under `jobs/job2_pkg/**` -> release job2
- changes under `libs/myproj_common/**` -> release common (+ rebuild jobs or relax pins)


## CI
This repo includes `.github/workflows/ci-dynamic.yml` which dynamically:
- detects changed package folders under `libs/*` and `jobs/*`
- enforces a version bump (`version = "..."`) in each changed package's `pyproject.toml`
- builds wheels and zips only for changed packages
