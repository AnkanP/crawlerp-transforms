from __future__ import annotations
from typing import Dict, List

def parse_kv(items: List[str] | None) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for kv in items or []:
        k, v = kv.split("=", 1)
        out[k] = v
    return out
