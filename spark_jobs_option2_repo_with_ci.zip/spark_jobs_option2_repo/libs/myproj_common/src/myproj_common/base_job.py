from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict
from pyspark.sql import SparkSession

class BaseJobExecutor(ABC):
    @abstractmethod
    def run(self, spark: SparkSession, job_args: Dict[str, Any]) -> None:
        ...
