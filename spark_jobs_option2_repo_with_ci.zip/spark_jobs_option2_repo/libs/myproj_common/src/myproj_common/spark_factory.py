from __future__ import annotations
from pyspark.sql import SparkSession

def make_spark(app_name: str) -> SparkSession:
    # Add Hive/Iceberg persistence via spark-submit --conf or SPARK_CONF_DIR.
    return SparkSession.builder.appName(app_name).getOrCreate()
