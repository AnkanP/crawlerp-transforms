from __future__ import annotations
from typing import Any, Dict
from pyspark.sql import SparkSession, functions as F
from myproj_common.base_job import BaseJobExecutor

class JobExecutor(BaseJobExecutor):
    """Example job: writes to a Hive table (parquet)."""
    def run(self, spark: SparkSession, job_args: Dict[str, Any]) -> None:
        db = job_args.get("db", "hdb")
        table = job_args.get("table", "job1_out")
        full = f"{db}.{table}"

        spark.sql(f"CREATE DATABASE IF NOT EXISTS {db}")
        spark.sql(f"CREATE TABLE IF NOT EXISTS {full} (id INT, value STRING) USING parquet")

        df = spark.createDataFrame([(1, "a"), (2, "b")], "id int, value string")                  .withColumn("ts", F.current_timestamp())
        df.createOrReplaceTempView("tmp_job1")
        spark.sql(f"INSERT INTO {full} SELECT id, value FROM tmp_job1")
        spark.sql(f"SELECT * FROM {full} ORDER BY id").show(truncate=False)
