from __future__ import annotations
import argparse
from myproj_common.cli import parse_kv
from myproj_common.spark_factory import make_spark
from job2_pkg.job_executor import JobExecutor

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arg", action="append", default=[], help="k=v (repeatable)")
    args = ap.parse_args()
    spark = make_spark("run-job2")
    JobExecutor().run(spark, parse_kv(args.arg))
    spark.stop()

if __name__ == "__main__":
    main()
