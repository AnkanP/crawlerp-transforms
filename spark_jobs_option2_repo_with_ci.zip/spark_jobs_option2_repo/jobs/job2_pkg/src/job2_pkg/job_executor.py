from __future__ import annotations
from typing import Any, Dict
from pyspark.sql import SparkSession
from myproj_common.base_job import BaseJobExecutor

class JobExecutor(BaseJobExecutor):
    """Example job: writes to an Iceberg table."""
    def run(self, spark: SparkSession, job_args: Dict[str, Any]) -> None:
        ns = job_args.get("namespace", "ice.idb")
        table = job_args.get("table", "job2_ice_out")
        full = f"{ns}.{table}"

        spark.sql(f"CREATE NAMESPACE IF NOT EXISTS {ns}")
        spark.sql(f"CREATE TABLE IF NOT EXISTS {full} (id INT, name STRING) USING iceberg")
        spark.sql(f"INSERT INTO {full} VALUES (10,'x'),(20,'y')")
        spark.sql(f"SELECT * FROM {full} ORDER BY id").show(truncate=False)
