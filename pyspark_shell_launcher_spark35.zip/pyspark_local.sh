#!/usr/bin/env bash
set -euo pipefail

# --- Move to repo root (so relative paths behave consistently) ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

# --- Activate venv ---
if [[ -f ".venv/bin/activate" ]]; then
  source ".venv/bin/activate"
else
  echo "ERROR: .venv/bin/activate not found. Run from repo root with a .venv." >&2
  exit 1
fi

# --- Versions ---
ICEBERG_VER="${ICEBERG_VER:-1.5.2}"

# --- Persistent local paths ---
BASE_DIR="${BASE_DIR:-$HOME/local_catalogs}"
HIVE_METASTORE_DB="${HIVE_METASTORE_DB:-$BASE_DIR/hive_metastore_db}"
HIVE_WAREHOUSE="${HIVE_WAREHOUSE:-$BASE_DIR/hive_warehouse}"
ICEBERG_WAREHOUSE="${ICEBERG_WAREHOUSE:-$BASE_DIR/iceberg_warehouse}"

mkdir -p "$HIVE_METASTORE_DB" "$HIVE_WAREHOUSE" "$ICEBERG_WAREHOUSE"

# --- Make your repo imports work (choose one style) ---
# If your code imports like: from src.common.utils import ...
export PYTHONPATH="${PYTHONPATH:-}:${REPO_ROOT}"

# If your code imports like: from common.utils import ...
# export PYTHONPATH="${PYTHONPATH:-}:${REPO_ROOT}/src"

echo "Using:"
echo "  VENV               : $VIRTUAL_ENV"
echo "  ICEBERG_VER        : $ICEBERG_VER"
echo "  PYTHONPATH         : $PYTHONPATH"
echo "  HIVE_METASTORE_DB  : $HIVE_METASTORE_DB"
echo "  HIVE_WAREHOUSE     : $HIVE_WAREHOUSE"
echo "  ICEBERG_WAREHOUSE  : $ICEBERG_WAREHOUSE"
echo ""

exec pyspark   --packages "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:${ICEBERG_VER}"   --conf "spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions"   --conf "spark.sql.catalog.ice=org.apache.iceberg.spark.SparkCatalog"   --conf "spark.sql.catalog.ice.type=hadoop"   --conf "spark.sql.catalog.ice.warehouse=${ICEBERG_WAREHOUSE}"   --conf "spark.sql.catalogImplementation=hive"   --conf "spark.sql.warehouse.dir=${HIVE_WAREHOUSE}"   --conf "javax.jdo.option.ConnectionURL=jdbc:derby:;databaseName=${HIVE_METASTORE_DB};create=true"   --conf "javax.jdo.option.ConnectionDriverName=org.apache.derby.jdbc.EmbeddedDriver"   --conf "datanucleus.schema.autoCreateAll=true"   --conf "hive.metastore.schema.verification=false"
