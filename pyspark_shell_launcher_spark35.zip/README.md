# PySpark launcher (Spark 3.5) — Hive(derby) + Iceberg(hadoop) persistent

Files:
- install_pyspark_launcher.sh  -> writes bin/pyspark_local.sh into your repo
- pyspark_local.sh             -> the launcher itself (reference)

Quick start:
1) From your repo root (where .venv/ exists):
   bash install_pyspark_launcher.sh

2) Launch:
   bin/pyspark_local.sh

Notes:
- Set PYTHONPATH in the launcher:
  * if you import as `from src.common...` keep repo-root in PYTHONPATH (default)
  * if you import as `from common...` switch to repo-root/src
- Persistence paths default to:
  ~/local_catalogs/hive_metastore_db
  ~/local_catalogs/hive_warehouse
  ~/local_catalogs/iceberg_warehouse
