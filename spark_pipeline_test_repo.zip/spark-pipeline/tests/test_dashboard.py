import pytest
from pyspark.sql import SparkSession
from pipeline import run_pipeline, generate_html_dashboard
import os

@pytest.fixture(scope="module")
def spark():
    spark = SparkSession.builder.master("local[2]").appName("TestDashboard").getOrCreate()
    yield spark
    spark.stop()

def test_dashboard_generation(spark, tmp_path):
    runtime_params = {"process_date": "2026-01-29","watermark": "2026-01-28 00:00:00"}
    final_df, metrics = run_pipeline("pipeline_config.yaml", runtime_params)
    dashboard_file = tmp_path / "pipeline_dashboard.html"
    generate_html_dashboard(
        ctes={"raw_contracts":{"depends_on":[]}, "customers_dim":{"depends_on":[]}},
        metrics_df=final_df.withColumnRenamed("contract_id","stage").toPandas(),
        process_date=runtime_params["process_date"],
        output_file=str(dashboard_file)
    )
    assert os.path.exists(dashboard_file)
    assert os.path.getsize(dashboard_file) > 0