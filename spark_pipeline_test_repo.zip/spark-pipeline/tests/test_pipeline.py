import pytest
from pyspark.sql import SparkSession
from pipeline import run_pipeline

@pytest.fixture(scope="module")
def spark():
    spark = SparkSession.builder.master("local[2]").appName("TestPipeline").getOrCreate()
    yield spark
    spark.stop()

def test_pipeline_local(spark):
    runtime_params = {"process_date": "2026-01-29","watermark": "2026-01-28 00:00:00"}
    final_df, metrics = run_pipeline("pipeline_config.yaml", runtime_params)
    assert final_df.count() > 0
    assert all([m["duplicate_count"] >= 0 for m in metrics.values()])
    assert set(["contract_id","customer_id"]).issubset(set(final_df.columns))