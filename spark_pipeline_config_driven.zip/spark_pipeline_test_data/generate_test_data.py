import os, yaml, random
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from faker import Faker
from datetime import datetime

fake = Faker()

def write_table(df, table_name, output_dir, process_date, formats):
    os.makedirs(output_dir, exist_ok=True)
    for fmt in formats:
        path = os.path.join(output_dir, f"{table_name}_{process_date}.{fmt}")
        if fmt=="csv":
            df.to_csv(path, index=False)
        elif fmt=="parquet":
            pq.write_table(pa.Table.from_pandas(df), path)
        print(f"[INFO] {table_name} written as {fmt.upper()}: {path}")

def generate_column(col_conf, fk_values=None):
    col_type = col_conf['type']
    if fk_values:
        return random.choice(fk_values)
    if col_type=='int':
        start = col_conf.get('start',1)
        max_val = col_conf.get('max',1000)
        return random.randint(start,max_val)
    elif col_type=='string':
        if 'values' in col_conf:
            return random.choice(col_conf['values'])
        elif col_conf.get('faker')=='first_name':
            return fake.first_name()
        elif col_conf.get('faker')=='last_name':
            return fake.last_name()
        else:
            return fake.word()
    elif col_type=='decimal':
        min_val = col_conf.get('min',0)
        max_val = col_conf.get('max',1000)
        return round(random.uniform(min_val,max_val),2)
    elif col_type=='timestamp':
        return fake.date_time_between(start_date='-30d', end_date='now')
    else:
        return None

def generate_table(table_name, table_conf, fk_cache):
    rows = table_conf.get('rows',10)
    columns_conf = table_conf['columns']
    output_formats = table_conf.get('output',['csv'])
    foreign_keys = table_conf.get('foreign_keys',{})

    fk_values_map = {}
    for col_name, fk_ref in foreign_keys.items():
        fk_table, fk_col = fk_ref.split('.')
        fk_values_map[col_name] = fk_cache[fk_table][fk_col].tolist()

    data = []
    for i in range(rows):
        row = {}
        for col_name, col_conf in columns_conf.items():
            fk_vals = fk_values_map.get(col_name)
            value = generate_column(col_conf, fk_vals)
            null_ratio = col_conf.get('null_ratio',0)
            if random.random()<null_ratio:
                value = None
            row[col_name]=value
        data.append(row)

    df = pd.DataFrame(data)

    for col_name, col_conf in columns_conf.items():
        if col_conf.get('duplicates',False):
            duplicates = df.sample(frac=0.1, replace=True)
            df = pd.concat([df,duplicates],ignore_index=True)

    return df, output_formats

def generate_all(config_file):
    with open(config_file) as f:
        config = yaml.safe_load(f)

    process_date = config.get('process_date', datetime.now().strftime('%Y-%m-%d'))
    output_dir = config.get('output_dir','tests/sample_data')

    fk_cache = {}
    for table_name, table_conf in config['tables'].items():
        df, formats = generate_table(table_name, table_conf, fk_cache)
        fk_cache[table_name] = df
        write_table(df, table_name, output_dir, process_date, formats)

    print('[INFO] All test tables generated successfully.')

if __name__=='__main__':
    generate_all('test_data_config.yaml')
