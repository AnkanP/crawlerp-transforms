# Jobs: Python Package + requirements.txt

Build and publish your wheel and upload requirements per release:
```bash
cd jobs/mypipeline
python -m pip install --upgrade build twine
python -m build

# Publish wheel to CodeArtifact (replace placeholders)
export AWS_REGION=eu-west-2
export CA_DOMAIN=my-domain
export CA_REPO=pypi-internal
export CA_OWNER=123456789012
export CA_TOKEN=$(aws codeartifact get-authorization-token --domain $CA_DOMAIN --domain-owner $CA_OWNER --query authorizationToken --output text --region $AWS_REGION)
python -m twine upload --repository-url https://$CA_DOMAIN-$CA_OWNER.d.codeartifact.$AWS_REGION.amazonaws.com/pypi/$CA_REPO/ -u aws -p $CA_TOKEN dist/*

# Upload requirements.txt to versioned S3 path
aws s3 cp jobs/requirements.txt s3://data-pipelines-artifacts/0.1.0/requirements.txt
```
