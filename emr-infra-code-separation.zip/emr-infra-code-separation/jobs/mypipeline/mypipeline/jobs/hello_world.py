from pyspark.sql import SparkSession
from datetime import datetime

def main():
    spark = SparkSession.builder.appName("mypipeline-hello").getOrCreate()
    now = datetime.utcnow().isoformat()
    df = spark.createDataFrame([(1, "EMR + CodeArtifact + requirements.txt"), (2, now)], ["id", "message"])
    df.show(truncate=False)
    spark.stop()

if __name__ == "__main__":
    main()
