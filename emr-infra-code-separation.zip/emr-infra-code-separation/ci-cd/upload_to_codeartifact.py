import os, subprocess, sys

def run(cmd):
    print("+", " ".join(cmd))
    subprocess.check_call(cmd)

AWS_REGION = os.environ.get("AWS_REGION", "eu-west-2")
CA_DOMAIN  = os.environ["CA_DOMAIN"]
CA_REPO    = os.environ["CA_REPO"]
CA_OWNER   = os.environ["CA_OWNER"]

# Build
run([sys.executable, "-m", "pip", "install", "--upgrade", "build", "twine"])
os.chdir("jobs/mypipeline")
run([sys.executable, "-m", "build"])
os.chdir("../../")

# Token
import json, subprocess
token = subprocess.check_output([
    "aws","codeartifact","get-authorization-token",
    "--domain", CA_DOMAIN, "--domain-owner", CA_OWNER,
    "--query","authorizationToken","--output","text",
    "--region", AWS_REGION
]).decode().strip()

# Upload
dist = "jobs/mypipeline/dist"
repo_url = f"https://{CA_DOMAIN}-{CA_OWNER}.d.codeartifact.{AWS_REGION}.amazonaws.com/pypi/{CA_REPO}/"
run([sys.executable, "-m", "twine", "upload", "--repository-url", repo_url, "-u","aws","-p", token, f"{dist}/*"])
print("Uploaded to CodeArtifact:", repo_url)
