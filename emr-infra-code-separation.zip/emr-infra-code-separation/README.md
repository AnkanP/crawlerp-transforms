# EMR + CodeArtifact + requirements.txt — Infra/Code Separation

This repository demonstrates a clean separation between **Infrastructure** (Terraform) and **Code** (PySpark jobs packaged as a wheel), with CI/CD that publishes artifacts and deploys EMR.

## Layout
```
infra/
  modules/emr_cluster/   # Terraform module for EMR
  environments/
    dev/                 # Dev environment wiring the module and pinning versions
    prod/                # Prod environment wiring the module and pinning versions
jobs/
  mypipeline/            # Python wheel with PySpark job(s)
  requirements.txt       # Public deps (private deps via CodeArtifact)
ci-cd/
  buildspec.yml          # CodeBuild script to build & publish artifacts, then deploy
  upload_to_codeartifact.py  # Helper to upload via Twine
```
