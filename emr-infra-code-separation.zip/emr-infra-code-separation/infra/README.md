# Infra

- `modules/emr_cluster` — reusable EMR module (bootstrap installs from CodeArtifact + requirements.txt from S3)
- `environments/{dev,prod}` — wire the module and pin your **release_version**

## Usage
```bash
cd infra/environments/dev
terraform init
terraform apply -auto-approve
```
Terraform reads `release_version` and constructs:
- `requirements_s3_uri = s3://data-pipelines-artifacts/<release_version>/requirements.txt`
- installs `mypipeline==<release_version>` from CodeArtifact
- runs step: `spark-submit -m mypipeline.jobs.hello_world`
```
