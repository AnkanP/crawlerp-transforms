# EMR Spark Submit Packaging Examples (Wheel + Bootstrap Requirements)

This bundle contains two packaging options:

## Option A: Separate wheels (recommended for independent versioning)
- `libs/common_lib/pyproject.toml` builds `common-lib`
- `apps/job1_app/pyproject.toml` builds `job1-app` (depends on `common-lib` by name)
- Submit by passing BOTH wheels in `--py-files`.

Example spark-submit:

```bash
spark-submit \
  --master yarn \
  --deploy-mode cluster \
  --py-files s3://.../common_lib-0.1.0.whl,s3://.../job1_app-1.2.3.whl \
  s3://.../drivers/job1_driver.py \
  --config s3://.../configs/job1/prod.yaml
```

## Option B: Vendored common (single wheel per app)
- `apps/job1_app/pyproject.toml` builds only `job1-app`
- `common_lib` code is included inside the same wheel
- Submit by passing only the job wheel in `--py-files`.

Example spark-submit:

```bash
spark-submit \
  --master yarn \
  --deploy-mode cluster \
  --py-files s3://.../job1_app-1.2.3.whl \
  s3://.../drivers/job1_driver.py \
  --config s3://.../configs/job1/prod.yaml
```
