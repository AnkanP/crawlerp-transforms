from common_lib.logging_utils import get_logger

def run(spark, config_path: str) -> None:
    logger = get_logger("job1_app")
    logger.info("Running job1 with config_path=%s", config_path)

    # Example: read something
    # df = spark.read.parquet("s3://bucket/path/")
    # logger.info("Row count: %s", df.count())
    logger.info("Job1 completed.")
