import argparse
from pyspark.sql import SparkSession

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="S3 path to job config (e.g., s3://.../job1/prod.yaml)")
    args = p.parse_args()

    spark = SparkSession.builder.appName("job1").getOrCreate()
    from job1_app.main import run
    run(spark=spark, config_path=args.config)
    spark.stop()

if __name__ == "__main__":
    main()
