# job1-app (vendored)

Contains common_lib vendored in the same wheel.
