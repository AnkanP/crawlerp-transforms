from common_lib.logging_utils import get_logger

def run(spark, config_path: str) -> None:
    logger = get_logger("job1_app")
    logger.info("Running job1 (vendored common) with config_path=%s", config_path)
    logger.info("Job1 completed.")
