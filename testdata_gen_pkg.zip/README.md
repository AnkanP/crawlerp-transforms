# Test Data Generator (Option A)

This package generates deterministic Spark test data from your CSV/Parquet fixtures and writes a baseline dataset
under an equivalent `<db>/<table>` folder structure.

## Folder conventions

Fixtures must be stored as:

```
<fixtures_dir>/<db>/<table>.csv
```

Example:

```
tests/fixtures/retail/contract.csv
tests/fixtures/retail/pccm_cci.csv
tests/fixtures/core/pcsm.csv
```

Baseline outputs will be written as:

```
<output_dir>/<db>/<table>.csv
```

**Note:** Spark writes CSV as a folder containing a `part-*.csv` file. This tool intentionally keeps the output folder
named `<table>.csv` for stable diffs.

## What it supports

- Expand templates to `rows=N` by sampling with replacement.
- Deterministic driver key overrides on the driver table (e.g., `contract.contract_id`, `date_processed`).
- Optional stage SQL to derive keys after joins (creates view `application_mapping`).
- Map all non-`pcsm` joins off `contract_id` via a short list of `table.column` targets.
- Special transforms:
  - `pri_ext.acct_num` derived from contract id via `strip_prefix`
  - `contract_id` built from concatenating 4 fields (`concat_cols`)
- Negative-case knobs:
  - `mismatch`: break a join key on a % of rows (set_null / set_random)
  - `explode`: duplicate a % of rows to create join explosions.

## Quickstart

1) Install deps in your environment (PySpark + PyYAML).

2) Put fixtures in `tests/fixtures/<db>/<table>.csv`.

3) Edit `examples/option_a.yml`.

4) Run:

```bash
python -m testdata_gen.cli --config examples/option_a.yml --write-baseline --show retail__contract
```

## Notes

- View naming: By default views are `<db>__<table>` to avoid collisions. Reference these names in stage SQL.
- This tool does *not* create managed tables; it creates temp views and writes baselines to disk.
  In your next step, you can add local Spark warehouse creation + teardown around this.
