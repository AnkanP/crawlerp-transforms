from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional

import yaml
from pyspark.sql import SparkSession, DataFrame, functions as F
from pyspark.sql.window import Window


# ------------------ basic generators ------------------
def gen_sequence(prefix: str, start: int, n: int) -> List[str]:
    return [f"{prefix}{start + i}" for i in range(n)]

def gen_date_range(start: str, end: str, n: int, seed: int) -> List[str]:
    rng = random.Random(seed)
    s = datetime.strptime(start, "%Y-%m-%d").date()
    e = datetime.strptime(end, "%Y-%m-%d").date()
    days = (e - s).days
    return [(s + timedelta(days=rng.randint(0, max(days, 0)))).isoformat() for _ in range(n)]

def gen_int_range(min_v: int, max_v: int, n: int, seed: int) -> List[int]:
    rng = random.Random(seed)
    return [rng.randint(min_v, max_v) for _ in range(n)]

def gen_enum(values: List[Any], n: int, seed: int) -> List[Any]:
    rng = random.Random(seed)
    return [rng.choice(values) for _ in range(n)]

def render_sql(sql: str, params: Dict[str, Any] | None) -> str:
    out = sql
    for k, v in (params or {}).items():
        out = out.replace("{{" + k + "}}", str(v))
    return out


# ------------------ filesystem discovery ------------------
def discover_templates(fixtures_dir: str, ext: str = ".csv") -> List[Dict[str, str]]:
    """
    Discover templates under: <fixtures_dir>/<db>/<table>.<ext>
    Returns list of {"db": db, "table": table, "path": path}.
    Only files exactly 2 levels deep are considered (db/table.ext).
    """
    root = Path(fixtures_dir)
    if not root.exists():
        raise FileNotFoundError(f"fixtures_dir not found: {fixtures_dir}")

    items: List[Dict[str, str]] = []
    for p in root.rglob(f"*{ext}"):
        rel = p.relative_to(root)
        parts = rel.parts
        if len(parts) != 2:
            continue
        db = parts[0]
        table = Path(parts[1]).stem
        items.append({"db": db, "table": table, "path": str(p)})
    return sorted(items, key=lambda x: (x["db"], x["table"]))


# ------------------ template read/write ------------------
def read_template(spark: SparkSession, path: str, fmt: str) -> DataFrame:
    fmt = fmt.lower()
    if fmt == "csv":
        return (
            spark.read
            .option("header", True)
            .option("inferSchema", True)
            .csv(path)
        )
    if fmt == "parquet":
        return spark.read.parquet(path)
    raise ValueError(f"Unsupported format: {fmt}")


def sample_to_n(df: DataFrame, n: int, seed: int) -> DataFrame:
    c = df.count()
    if c == 0:
        raise ValueError("Template dataset is empty.")
    reps = (n // c) + 2
    unioned = None
    for i in range(reps):
        chunk = df.orderBy(F.rand(seed + i))
        unioned = chunk if unioned is None else unioned.unionByName(chunk, allowMissingColumns=True)
    return unioned.limit(n)


def with_row_id(df: DataFrame) -> DataFrame:
    # used to align per-row overrides deterministically
    return df.withColumn("_rid", F.monotonically_increasing_id())


def apply_column_override(df: DataFrame, col: str, values: List[Any]) -> DataFrame:
    """
    Assign override values by deterministic row order based on _rid.
    """
    spark = df.sparkSession
    vdf = spark.createDataFrame([(i, v) for i, v in enumerate(values)], ["_idx", "_val"])
    w = Window.orderBy("_rid")
    df2 = df.withColumn("_idx", F.row_number().over(w) - 1)
    out = (
        df2.join(vdf, on="_idx", how="left")
           .drop("_idx")
           .withColumn(col, F.col("_val"))
           .drop("_val")
    )
    return out


# ------------------ derive columns (intra-table) ------------------
def apply_derive_expr(df: DataFrame, target_col: str, expr_cfg: Dict[str, Any]) -> DataFrame:
    """
    Supported kinds:
      - regex_extract: extract contract/application id from string/struct-as-string
      - concat: concat literals and columns
      - substring: substring(source, pos, len)
    """
    kind = expr_cfg["kind"]

    if kind == "regex_extract":
        src = expr_cfg["source_column"]
        pattern = expr_cfg["pattern"]
        group = int(expr_cfg.get("group", 1))
        return df.withColumn(target_col, F.regexp_extract(F.col(src).cast("string"), pattern, group))

    if kind == "concat":
        parts = []
        for p in expr_cfg["parts"]:
            if "literal" in p:
                parts.append(F.lit(p["literal"]))
            elif "column" in p:
                parts.append(F.col(p["column"]).cast("string"))
            else:
                raise ValueError(f"concat part must be literal or column: {p}")
        return df.withColumn(target_col, F.concat(*parts))

    if kind == "substring":
        src = expr_cfg["source_column"]
        pos = int(expr_cfg["pos"])
        length = int(expr_cfg.get("len", 999))
        return df.withColumn(target_col, F.substring(F.col(src).cast("string"), pos, length))

    raise ValueError(f"Unsupported derive expr kind: {kind}")


# ------------------ mismatch & explode ------------------
def apply_mismatch(df: DataFrame, key_col: str, missing_rate: float, mode: str, seed: int) -> DataFrame:
    """
    Break join keys on a fraction of rows.
    mode:
      - set_null
      - set_random (deterministic-ish)
    """
    r = F.rand(seed)
    if mode == "set_null":
        return df.withColumn(key_col, F.when(r < missing_rate, F.lit(None)).otherwise(F.col(key_col)))
    if mode == "set_random":
        return df.withColumn(
            key_col,
            F.when(r < missing_rate, F.concat(F.lit("X"), F.sha2(F.col("_rid").cast("string"), 256).substr(1, 12)))
             .otherwise(F.col(key_col))
        )
    raise ValueError(f"Unsupported mismatch mode: {mode}")


def apply_explode_duplicates(df: DataFrame, duplicate_rate: float, seed: int) -> DataFrame:
    dup = df.filter(F.rand(seed) < duplicate_rate)
    return df.unionByName(dup, allowMissingColumns=True)


# ------------------ special transforms ------------------
def strip_prefix(col_expr: F.Column, prefix: str) -> F.Column:
    # Spark substring is 1-based
    return F.when(col_expr.startswith(prefix), F.substring(col_expr, len(prefix) + 1, 999)).otherwise(col_expr)


def build_concat_key(df: DataFrame, target_col: str, cols: List[str], sep: str = "", pad: Optional[Dict[str, Dict[str, Any]]] = None) -> DataFrame:
    """
    Build a key by concatenating multiple columns, optionally padding individual components.
    pad example: {"field2": {"len": 2, "char": "0"}}
    """
    pad = pad or {}
    parts: List[F.Column] = []
    for c in cols:
        ce = F.col(c).cast("string")
        if c in pad:
            ln = int(pad[c]["len"])
            ch = str(pad[c].get("char", "0"))
            ce = F.lpad(ce, ln, ch)
        parts.append(ce)

    if sep:
        exprs: List[F.Column] = []
        for i, p in enumerate(parts):
            if i > 0:
                exprs.append(F.lit(sep))
            exprs.append(p)
        return df.withColumn(target_col, F.concat(*exprs))
    return df.withColumn(target_col, F.concat(*parts))


# ------------------ stages (derived keys after joins) ------------------
def run_stages(spark: SparkSession, tables_by_view: Dict[str, DataFrame], cfg: Dict[str, Any]) -> Dict[str, DataFrame]:
    """
    Register existing views, execute stage SQL, and register stage outputs as views.
    Stage definitions are optional. If you use stage_mapping_sql (Option A), this creates view `application_mapping`.
    """
    for name, df in tables_by_view.items():
        df.createOrReplaceTempView(name)

    params = cfg.get("params", {})
    stages = cfg.get("stages", [])
    # Option A convenience
    if "stage_mapping_sql" in cfg:
        stages = stages + [{"name": "application_mapping", "sql": cfg["stage_mapping_sql"]}]

    for st in stages:
        sql = render_sql(st["sql"], params)
        df = spark.sql(sql)
        tables_by_view[st["name"]] = df
        df.createOrReplaceTempView(st["name"])

    return tables_by_view


# ------------------ main generator ------------------
def generate_from_fixtures(spark: SparkSession, cfg: Dict[str, Any]) -> Tuple[Dict[str, DataFrame], Dict[Tuple[str, str], DataFrame]]:
    """
    Returns:
      views: Dict[view_name, DataFrame]         (for temp views)
      tables: Dict[(db, table), DataFrame]      (for writing baseline with db/table structure)
    """
    seed = int(cfg.get("seed", 42))
    n = int(cfg.get("rows", 200))

    fixtures_dir = cfg["fixtures_dir"]
    io = cfg.get("io", {})
    fmt = io.get("format", "csv").lower()
    ext = ".csv" if fmt == "csv" else ".parquet"

    discovered = discover_templates(fixtures_dir, ext=ext)

    # load and expand templates
    tables: Dict[Tuple[str, str], DataFrame] = {}
    views: Dict[str, DataFrame] = {}

    # handle potential duplicate table names across DBs by using db__table view names
    use_db_prefix = bool(cfg.get("view_names", {}).get("db_prefix", True))

    for it in discovered:
        db, table, path = it["db"], it["table"], it["path"]
        df = read_template(spark, path, fmt)
        df = sample_to_n(df, n, seed=seed + (hash(f"{db}.{table}") % 10_000))
        df = with_row_id(df)
        tables[(db, table)] = df

        view_name = f"{db}__{table}" if use_db_prefix else table
        views[view_name] = df

    # Optional intra-table derivations (before driver keys / mappings)
    for d in cfg.get("derive_columns", []):
        table_ref = d["table"]  # can be "db.table" or just "table" if unique
        target_col = d["target_column"]
        expr_cfg = d["expr"]
        # resolve view name
        view = _resolve_view_name(table_ref, use_db_prefix)
        views[view] = apply_derive_expr(views[view], target_col, expr_cfg)

    # Apply driver keys
    driver = cfg.get("driver", {})
    driver_table_ref = driver.get("table", "contract")
    driver_view = _resolve_view_name(driver_table_ref, use_db_prefix)

    for key, gen in (driver.get("keys", {}) or {}).items():
        if gen["kind"] == "sequence":
            vals = gen_sequence(gen["prefix"], int(gen["start"]), n)
        elif gen["kind"] == "date_range":
            vals = gen_date_range(gen["start"], gen["end"], n, seed + hash(f"{driver_view}.{key}") % 10_000)
        elif gen["kind"] == "enum":
            vals = gen_enum(gen["values"], n, seed + hash(f"{driver_view}.{key}") % 10_000)
            # optional padding for enum/int not applied here
        elif gen["kind"] == "int_range":
            vals = gen_int_range(int(gen["min"]), int(gen["max"]), n, seed + hash(f"{driver_view}.{key}") % 10_000)
            # optional padding at dataframe level can be added via derive if needed
        else:
            raise ValueError(f"Unsupported driver generator: {gen['kind']}")

        views[driver_view] = apply_column_override(views[driver_view], key, vals)

    # Controlled fields (optional)
    for item in cfg.get("controlled_fields", []):
        table_ref, col = item["column"].split(".", 1)
        view = _resolve_view_name(table_ref, use_db_prefix)
        gen = item["generator"]

        if gen["kind"] == "enum":
            vals = gen_enum(gen["values"], n, seed + hash(item["column"]) % 10_000)
        elif gen["kind"] == "int_range":
            vals = gen_int_range(int(gen["min"]), int(gen["max"]), n, seed + hash(item["column"]) % 10_000)
        elif gen["kind"] == "date_range":
            vals = gen_date_range(gen["start"], gen["end"], n, seed + hash(item["column"]) % 10_000)
        else:
            raise ValueError(f"Unsupported generator kind: {gen['kind']}")
        views[view] = apply_column_override(views[view], col, vals)

    # Re-register views and run stages (derived keys after joins)
    views = run_stages(spark, views, cfg)

    # Convenience: get driver columns for mapping
    driver_df = views[driver_view].select("_rid", F.col("contract_id").alias("__contract_id"))
    if "date_processed" in views[driver_view].columns:
        driver_df = driver_df.withColumn("__date_processed", F.col("date_processed"))
    else:
        driver_df = driver_df.withColumn("__date_processed", F.lit(None))

    # 1) map contract keys to listed columns (Option A)
    joins = cfg.get("joins", {})
    for full in joins.get("contract_key_columns", []) or []:
        t_ref, c = full.split(".", 1)
        view = _resolve_view_name(t_ref, use_db_prefix)
        if view not in views:
            continue
        df = views[view].join(driver_df, on="_rid", how="left")
        df = df.withColumn(c, F.col("__contract_id")).drop("__contract_id", "__date_processed")
        views[view] = df

    # 2) special rules
    special = joins.get("special", {}) or {}
    for target_full, rule in special.items():
        t_ref, tgt_col = target_full.split(".", 1)
        view = _resolve_view_name(t_ref, use_db_prefix)
        if view not in views:
            continue

        if "from" in rule and rule.get("transform", {}).get("kind") == "strip_prefix":
            prefix = rule["transform"]["prefix"]
            src_table_ref, src_col = rule["from"].split(".", 1)
            if _resolve_view_name(src_table_ref, use_db_prefix) != driver_view:
                raise ValueError("strip_prefix currently supports source from driver table only.")
            df = views[view].join(driver_df, on="_rid", how="left")
            df = df.withColumn(tgt_col, strip_prefix(F.col("__contract_id"), prefix)).drop("__contract_id", "__date_processed")
            views[view] = df
            continue

        if "build" in rule and rule["build"]["kind"] == "concat_cols":
            b = rule["build"]
            cols = b["cols"]
            sep = b.get("sep", "")
            pad = b.get("pad", None)
            views[view] = build_concat_key(views[view], tgt_col, cols=cols, sep=sep, pad=pad)
            continue

        raise ValueError(f"Unsupported special rule for {target_full}: {rule}")

    # 3) pcsm mapping from stage output (application_id) keyed by contract_id
    pcsm_cfg = joins.get("pcsm", {}) or {}
    if "application_id_from_stage" in pcsm_cfg:
        stage_view = pcsm_cfg["application_id_from_stage"]
        if stage_view not in views:
            raise ValueError(f"Stage view not found: {stage_view}")
        stage_df = views[stage_view]
        if "contract_id" not in stage_df.columns or "application_id" not in stage_df.columns:
            raise ValueError("Stage must produce columns: contract_id, application_id")

        # find pcsm view(s): any view that endswith '__pcsm' or equals 'pcsm'
        pcsm_views = [k for k in views.keys() if k.endswith("__pcsm") or k == "pcsm"]
        for pv in pcsm_views:
            df = views[pv]
            # If pcsm has contract_id column, map by contract_id; else map by _rid alignment (fallback)
            if "contract_id" in df.columns:
                mapped = stage_df.select("contract_id", "application_id").dropDuplicates(["contract_id"])
                df = df.join(mapped, on="contract_id", how="left").withColumn("application_id", F.col("application_id"))
            else:
                # fallback: align by _rid to driver, then by contract_id
                df = df.join(driver_df.select("_rid", "__contract_id"), on="_rid", how="left")
                mapped = stage_df.select(F.col("contract_id").alias("__contract_id"), "application_id").dropDuplicates(["__contract_id"])
                df = df.join(mapped, on="__contract_id", how="left").withColumn("application_id", F.col("application_id")).drop("__contract_id")
            views[pv] = df

    # 4) mismatch
    mismatch = cfg.get("mismatch", {}) or {}
    for full, mc in mismatch.items():
        t_ref, col = full.split(".", 1)
        view = _resolve_view_name(t_ref, use_db_prefix)
        if view not in views:
            continue
        rate = float(mc.get("rate", 0.0))
        mode = mc.get("mode", "set_null")
        if rate > 0:
            views[view] = apply_mismatch(views[view], col, rate, mode, seed + hash(full) % 10_000)

    # 5) explode duplicates
    explode = cfg.get("explode", {}) or {}
    for t_ref, rate in explode.items():
        view = _resolve_view_name(t_ref, use_db_prefix)
        if view not in views:
            continue
        dr = float(rate)
        if dr > 0:
            views[view] = apply_explode_duplicates(views[view], dr, seed + 777 + hash(view) % 10_000)

    # cleanup: drop internal _rid, and rebuild tables dict from views by mapping back
    cleaned_views: Dict[str, DataFrame] = {}
    for vn, df in views.items():
        cleaned_views[vn] = df.drop("_rid") if "_rid" in df.columns else df

    # produce output tables in (db, table) naming based on view names
    cleaned_tables: Dict[Tuple[str, str], DataFrame] = {}
    for (db, table), _df in tables.items():
        vn = f"{db}__{table}" if use_db_prefix else table
        cleaned_tables[(db, table)] = cleaned_views[vn]

    return cleaned_views, cleaned_tables


def _resolve_view_name(table_ref: str, use_db_prefix: bool) -> str:
    """
    Resolve "db.table" or "table" into a view name.
    If db prefixing is enabled, view is db__table.
    If table_ref has no db, returns table_ref unchanged.
    """
    if "." in table_ref:
        db, table = table_ref.split(".", 1)
        return f"{db}__{table}" if use_db_prefix else table
    return table_ref


def write_baseline_outputs(tables: Dict[Tuple[str, str], DataFrame], cfg: Dict[str, Any]) -> None:
    """
    Write generated tables into <output_dir>/<db>/<table>.csv (Spark CSV folder) or parquet.
    """
    out_dir = Path(cfg["output_dir"])
    io = cfg.get("io", {})
    fmt = io.get("format", "csv").lower()
    out_dir.mkdir(parents=True, exist_ok=True)

    for (db, table), df in tables.items():
        db_dir = out_dir / db
        db_dir.mkdir(parents=True, exist_ok=True)

        if fmt == "csv":
            # Spark writes CSV as a folder; we keep folder naming stable as "<table>.csv"
            out_path = str(db_dir / f"{table}.csv")
            (df.coalesce(1)
               .write
               .mode(io.get("csv", {}).get("mode", "overwrite"))
               .option("header", str(io.get("csv", {}).get("header", True)).lower())
               .csv(out_path))
        elif fmt == "parquet":
            out_path = str(db_dir / table)
            (df.write
               .mode(io.get("parquet", {}).get("mode", "overwrite"))
               .parquet(out_path))
        else:
            raise ValueError(f"Unsupported output format: {fmt}")
