from __future__ import annotations

import argparse
from pathlib import Path

import yaml
from pyspark.sql import SparkSession

from testdata_gen.generator import generate_from_fixtures, write_baseline_outputs


def main():
    ap = argparse.ArgumentParser(description="Generate deterministic Spark test data from fixtures and write baselines.")
    ap.add_argument("--config", required=True, help="Path to YAML config (Option A).")
    ap.add_argument("--write-baseline", action="store_true", help="Write generated tables to output_dir.")
    ap.add_argument("--show", nargs="*", default=[], help="Optional list of views to show()")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    spark = (
        SparkSession.builder
        .master("local[2]")
        .appName("testdata-gen")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )

    views, tables = generate_from_fixtures(spark, cfg)

    for v in args.show:
        if v not in views:
            print(f"[WARN] view not found: {v}. Available: {list(views.keys())[:10]} ...")
            continue
        print(f"\n=== VIEW: {v} ===")
        views[v].show(20, truncate=False)

    if args.write_baseline:
        write_baseline_outputs(tables, cfg)
        print(f"\nWrote baseline outputs under: {cfg['output_dir']}")

    spark.stop()


if __name__ == "__main__":
    main()
